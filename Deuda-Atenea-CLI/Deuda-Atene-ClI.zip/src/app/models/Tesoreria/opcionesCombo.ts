export class OpcionesCombo{
    id_combo: number;
    descripcion_combo: string;
}