export class Moneda{
    t064Id: string;
    t064Description: string;
    t064Status: boolean;
}