export class HistoricoModificacion{
    t486_id: number;
    t486_id_process: number;
    t486_table_name: string;
    t486_table_register_id: string;
    t486_column_name: string;
    t486_previous_value: string;
    t486_new_value: string;
    t486_registered_by: string;
    t486_register_date: Date;
}