export class EstructuraCorreo{
    destinatarios: string;
    asunto: string;
    copiar: string;
    cuerpo: string;
    importante: boolean;
    adjuntos: string[];
}