export class Cuponera{
    id: number;
    id_co: string;
    start_date: number;
    end_date: number;
    coupon: number;
    amortization: number;
    residue: number;
}