export class Subsidiaria{
    t453Id: number;
    t453Description: string;
    t453Country: string;
    t453Currency: string;
    t453Status: boolean;
    t453StatusBlackList: boolean;
    t453DescriptionTreasury: string;
}