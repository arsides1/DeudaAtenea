export class TipoOC{
    t445_id: string;
    t445_description: string;
    t445_status: boolean;
}