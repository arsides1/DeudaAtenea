export class Holiday{
    date_key: number;
    country: string;
    status: number;
    holiday_concept: number;
}