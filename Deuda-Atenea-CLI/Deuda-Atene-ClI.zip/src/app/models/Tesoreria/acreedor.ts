export class Acreedor{
    id: number;
    description: string;
    country: string;
}