export class Basis{
    t448_id: number;
    t448_description: string;
    t448_code_bbg: string;
    t448_status: boolean;
}