export class RolPorUsuario{
    id: number;
    idUsuario: number;
    nombre: string;
    idRol: number;
    descripcionRol: string;
}