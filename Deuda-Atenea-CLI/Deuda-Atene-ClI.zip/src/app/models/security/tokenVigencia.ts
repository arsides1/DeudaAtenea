export class TokenVigencia{
    id: number;
    usuario_id: number;
    token: string;
    fecha_creacion: Date;
    fecha_expiracion: Date;
    status: boolean;
}