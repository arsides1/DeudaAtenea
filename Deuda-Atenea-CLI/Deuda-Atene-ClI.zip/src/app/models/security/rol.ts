export class Rol{
    id: number;
    rolNombre: string;
    estado: number;
    descripcion: string;
}