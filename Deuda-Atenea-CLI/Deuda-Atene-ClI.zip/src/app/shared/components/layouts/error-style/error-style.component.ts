import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-style',
  templateUrl: './error-style.component.html',
  styleUrls: ['./error-style.component.scss']
})
export class ErrorStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
