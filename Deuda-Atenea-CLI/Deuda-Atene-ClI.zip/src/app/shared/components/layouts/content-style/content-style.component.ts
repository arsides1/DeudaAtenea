import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-style',
  templateUrl: './content-style.component.html',
  styleUrls: ['./content-style.component.scss']
})
export class ContentStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
