import { Injectable } from '@angular/core';
// import {AngularFireDatabase} from '@angular/fire/database';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor( ) { }
  getTaskList() {
  }
  addTask(task: string) {
  }
  checkOrUnCheckTask(key: string, flag: boolean) {
  }

  removeTask(task: string) {
  }
}
