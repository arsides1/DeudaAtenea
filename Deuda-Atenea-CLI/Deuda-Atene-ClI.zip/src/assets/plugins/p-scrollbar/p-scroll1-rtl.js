(function($) {
    "use strict";

    //P-scrolling
    const ps = new PerfectScrollbar('.app-sidebar3', {
        useBothWheelAxes: false,
        suppressScrollX: false,
        wheelPropagation: false
    });

})(jQuery);